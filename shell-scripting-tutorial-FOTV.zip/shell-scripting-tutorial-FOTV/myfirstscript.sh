#!/bin/bash
#Purpose: This is my first script in this shell scripting video tutorial
#Date: Wed May  2 17:10:13 IST 2018
#Author: Ankam Ravi Kumar
#Version: 1.0
#Modified Date:
#Modified by:

# START
echo "Welcome $USER"
echo "Your present working directory is `pwd`"
echo "Today date is `date`"
# END
