#!/bin/bash
#Purpose:Arthmetic operators using expr command
#Version:1.0
#Created Date: Wed May 9 21:47:04 IST 2018
#Modified Date:
#website: https://arkit.co.in
#Author: Ankam Ravi Kumar
# START #
echo -e "Enter value: \c"
read -r a
echo -e "Enter value: \c"
read -r b

echo "addition values `expr $a + $b`"
echo "minus values `expr $a - $b`"
echo "multiplied by values `expr $a \* $b`"
echo "devided by values `expr $a / $b`"
echo "remainder values `expr $a % $b`"
echo "addition values `expr $a + $b`"

echo "Completed Sucessfully"
# END #
