#!/bin/bash
#Purpose: eval command Evaluating twice
#Version:1.0
#Created Date: Wed Jun 13 22:09:59 IST 2018
#Modified Date:
#WebSite: https://arkit.co.in
#Author: Ankam Ravi Kumar
# START #

echo "WEL COME TO $USER"
echo "Your present working directory is `pwd`"
echo "current logged in users are `who`"
echo "Today date is `date`"

# END #
