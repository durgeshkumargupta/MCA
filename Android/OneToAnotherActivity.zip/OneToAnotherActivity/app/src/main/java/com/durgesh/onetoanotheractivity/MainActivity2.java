package com.durgesh.onetoanotheractivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    public static final String NAME="NAME";
    public static final String AGE="AGE";

    private String name;
    private int age;


    private TextView textView1,textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        textView1=findViewById(R.id.textView6);
        textView2=findViewById(R.id.textView5);

        Intent i=getIntent();
        name=i.getStringExtra(NAME);
        age=i.getIntExtra(AGE,0);

        textView1.setText("Your Name is "+name);
        textView2.setText("Your Age is "+age);

    }
}