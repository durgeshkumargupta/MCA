package com.durgesh.sqliteapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateUser extends AppCompatActivity {

    private EditText t1,t2,t3,t4;
    private Button b1;
    private MyDbHandler myDbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_user);


        t1=findViewById(R.id.id);
        t2=findViewById(R.id.name);
        t3=findViewById(R.id.address);
        t4=findViewById(R.id.phone);

        myDbHandler=Temp.getMyDbHandler();
    }
    public void updateUser(View view)
    {
        String id=t1.getText().toString();
        String name=t2.getText().toString();
        String email=t3.getText().toString();
        String phone=t4.getText().toString();

        if(id.equals("") || name.equals("") || email.equals("") || phone.equals(""))
            Toast.makeText(this, "Please Fill All Fields", Toast.LENGTH_SHORT).show();
        else
        {
            User user=new User();
            user.setId(id);
            user.setName(name);
            user.setEmail(email);
            user.setMobile(phone);
            boolean i=myDbHandler.updateValue(user);
            if(i==true)
                Toast.makeText(this, "Record Updated", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, "Record not Updated", Toast.LENGTH_SHORT).show();
        }

    }


}