package com.durgesh.sqliteapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DeleteUser extends AppCompatActivity {

    private EditText editText;
    private Button b1;
    private MyDbHandler myDbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_user);

        editText=findViewById(R.id.editTextTextPersonName);

        myDbHandler=Temp.getMyDbHandler();
    }
    public void delete(View view)
    {
        String id=editText.getText().toString();
        if(id.equals(""))
            Toast.makeText(this, "Please Enter User ID", Toast.LENGTH_SHORT).show();
        else {
            User user=new User();
            user.setId(id);
            int i=myDbHandler.deleteUser(id);
            if(i==1)
                Toast.makeText(this, "Your Values is Delete Successfully", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, " Oops!! Values is not Delete", Toast.LENGTH_SHORT).show();
        }


    }
}