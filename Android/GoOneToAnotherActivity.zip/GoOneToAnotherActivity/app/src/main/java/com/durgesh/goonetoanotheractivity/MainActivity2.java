package com.durgesh.goonetoanotheractivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    private TextView textView1,textView2,textView3,textView4,textView5;

    public static final String NAME="NAME";
    public static final String CONCERN="CONCERN";
    public static final String ADDRESS="ADDRESS";
    public static final String PHONE="PHONE";
    public static final String EMAIL="EMAIL";

    private String name;
    private String concern;
    private String address;
    private String phone;
    private String email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);



        textView1=findViewById(R.id.textView1);
        textView2=findViewById(R.id.textView2);
        textView3=findViewById(R.id.textView3);
        textView4=findViewById(R.id.textView4);
        textView5=findViewById(R.id.textView5);


        Intent intent=getIntent();

        name=intent.getStringExtra(NAME);
        concern=intent.getStringExtra(CONCERN);
        address=intent.getStringExtra(ADDRESS);
        email=intent.getStringExtra(EMAIL);
        phone=intent.getStringExtra(PHONE);


        textView1.setText("Name: "+name);
        textView2.setText("Concern: "+concern);
        textView3.setText("Address: "+address);
        textView4.setText("Email: "+email);
        textView5.setText("Phone: "+phone);


    }
}